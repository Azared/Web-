const express = require('express');
const path = require('path');
const app = express();

// Servir los archivos estáticos de la carpeta build
app.use(express.static(path.join(__dirname, 'build')));

// Enviar el index.html para cualquier ruta que no se maneje
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

const PORT = process.env.PORT || 5000; // O el puerto que desees
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
